title: 我在 GitHub 上的开源项目
date: '2023-01-05 12:53:44'
updated: '2023-02-10 17:20:31'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](/images/github_repo.jpg)

## Github Stats

![Github Stats](https://github-readme-stats.vercel.app/api?username=Ruinwalker7&show_icons=true) 

## 所有开源项目
| 仓库 |  项目简介 | Stars | fork | 编程语言 |
| ---- | ---- | ---- | ---- | ---- |
| [bolo-blog](https://github.com/Ruinwalker7/bolo-blog) | ✍️ 辰的个人博客 - 一个独处的小空间 | 0 | 0 | |
| [Broadcast-Whitepaper-SAA](https://github.com/Ruinwalker7/Broadcast-Whitepaper-SAA) | 深圳中学学生活动中心十大直播白皮书 | 0 | 0 | |
| [CSUAutoSelect](https://github.com/Ruinwalker7/CSUAutoSelect) | 中南大学自动选课脚本 | 0 | 0 | Python|
| [FYT-sentry](https://github.com/Ruinwalker7/FYT-sentry) |  | 0 | 0 | C++|
| [GuessGame](https://github.com/Ruinwalker7/GuessGame) | a guess game with javafx | 0 | 0 | Java|
| [rm_decision](https://github.com/Ruinwalker7/rm_decision) | FYT战队哨兵自主决策代码，利用behaviorTree.cpp和gazebo实现虚拟仿真 | 0 | 0 | C++|
| [Ruinwalker7](https://github.com/Ruinwalker7/Ruinwalker7) |  | 0 | 0 | |
| [Study-Note](https://github.com/Ruinwalker7/Study-Note) | 学习过程中的笔记 | 0 | 0 | |
