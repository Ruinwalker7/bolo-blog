title: '[程序分享]Excel表格转latex'
date: '2023-01-13 21:55:59'
updated: '2023-02-10 17:22:35'
tags: [latex]
permalink: /articles/2023/01/13/1673618159838.html
---
<img alt="Snipaste_2023-02-10_17-22-17.jpg" src="http://120.133.136.23:8888/uploadImages/113/110/166/3/2023/02/10/17/22/82ac7729-5bea-4d7d-b6e5-1d12a3389275.jpg">
latex写文章很方便，不用过分注重格式，而可以专注于内容，但是latex的表格非常的难写，这里推荐一个小脚本可以将Excel中表格转换为latex

先上链接：[github链接](https://github.com/ivankokan/Excel2LaTeX)
下载完成后，使用excel的加载项功能加载插件

<img alt="20230113215553110.png" src="http://120.133.136.23:8888/uploadImages/113/110/166/3/2023/02/10/17/20/7a0873ea-bee1-4cef-8a32-4e9726a685bd.png">

选中表格后点击工具栏加载项中Convert Table to LateX

<img src="http://120.133.136.23:8888/uploadImages/113/110/166/3/2023/02/10/17/20/cb81265a-5a65-4207-aaeb-c188424b2bf0.png" style="zoom: 50%;" />

复制弹出窗口中的代码到latex编辑器中，即可生成表格
可以比较完美的转换，包括边框的粗细，文字的字体等等

