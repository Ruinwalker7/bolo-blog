title: '[程序分享]CSU抢课小程序'
date: '2023-01-11 23:08:44'
updated: '2023-02-10 23:09:43'
tags: [中南大学, 脚本]
permalink: /articles/2023/01/11/1673449724728.html
---
![image.png](http://120.133.136.23:8888//uploadImages/120/133/136/23/2023/02/10/23/09/229cd597-7316-437f-98ac-ffadaa456013.png)

### 文章前言

本软件暂时只适用于2022-2023学年第二学期抢课脚本，因为不知道每年是否会更换后台请求的内容。
先上[github链接](https://github.com/Ruinwalker7/CSUAutoSelect)

### 准备工作

1.Python的编译环境
2.requests包安装

在终端输入

```
pip install python
```

### 教程

1.下载github上的源码
2. 修改config.ini文件中的配置，如果需要抢多门课，可以修改num
3. 运行.py文件，会在当前文件夹生成code.jpg文件，需要手动输入验证码
4. 目前测试来看，抢公选课和必选课的请求地址不同
第一行为公选课请求地址，第二行为专业课抢课地址

```
REQUEST_URL ='http://csujwc.its.csu.edu.cn/jsxsd/xsxkkc/ggxxkxkOper'
REQUEST_URL = 'http://csujwc.its.csu.edu.cn/jsxsd/xsxkkc/bxqjhxkOper'
```

5.为了避免前面的课无法选而不能选后面的，软件轮流对每个课程发包选课
6.所有课程的id可以在CSU教务系统中，各类系统查询，点击按时间查询即可搜索到每个课程的id

### 文章后言

程序中设置的频率都比较低，请不要设置过高请求对服务器造成太大负担，这违背了这个软件开发的初衷，每个班级的名额也很多，这种频率也能够成功抢课，祝大家抢课顺利。
<img alt="20230111230653783.jpg" src="http://120.133.136.23:8888/uploadImages/113/110/166/3/2023/02/10/17/26/0d7a5269-0ca2-48ca-bb57-c9271661193f.jpg">

