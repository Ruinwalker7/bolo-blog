title: '[开发记录] BehaviorTree.cpp行为树'
date: '2023-03-16 17:22:00'
updated: '2023-03-16 18:29:10'
tags: [行为树, Robomaster]
permalink: /articles/2023/03/16/1678962269955.html
---
<img alt="Snipaste_2023-03-16_18-28-33.jpg" src="http://120.133.136.23:8888/uploadImages/110/53/160/6/2023/03/16/18/28/fc876ce5-caca-41c6-b709-75116d8156c3.jpg">

# 行为树

- 主要使用的是GitHub上的一个开源库`BehaviorTree.cpp`

[开源链接](https://github.com/BehaviorTree/BehaviorTree.CPP)

[教程](https://www.behaviortree.dev/)

[Robomaster哨兵应用开源](https://github.com/Ruinwalker7/rm_decision)

## 基本概念

行为树是一种树结构的层次节点，通过“tick”信号在树中传递

一个“tick”信号从树的根节点传递到叶子节点，每一个节点都必须返回以下的三个值

```
SUCCESS
FAILURE
RUNNING
```

`RUNNING`只是这个节点需要更多时间来完成任务

树中的节点有以下类型：

<img alt="image-20230316181301517.png" src="http://120.133.136.23:8888/uploadImages/110/53/160/6/2023/03/16/18/22/1c092010-1303-4877-a0b8-49e0f2f38724.png" style="zoom:67%;">

在`ActionNode`中有可能会返回`Running`结果，我们需要再次"tick"这个节点，直到返回`SUCCESS`或`FAILURE`

## 节点详解

### `ControlNode`

控制节点的子节点总是按顺序排列的

#### `Sequence`

如果节点返回的是`SUCCESS`，则"tick"下一个节点，`Sequence`有两个变种节点

<img alt="image-20230316180626696.png" src="http://120.133.136.23:8888/uploadImages/110/53/160/6/2023/03/16/18/22/f1f31998-3463-47ef-bf4d-ec60f5b1a49c.png" style="zoom:67%;">

### `DecoratorNode`

装饰节点，通常只有一个孩子

#### `InverterNode`

反转结果，SUCCESS返回FAILURE，FAILURE返回SUCCESS

#### `ForceSuccessNode`

子节点返回`RUNNING`则返回`RUNNING`，否则返回`SUCCESS`

#### `ForceFailureNode`

与上面相同

#### `RepeatNode`

重复N次，直到返回失败，N是可以输入的

#### `RetryNode`

重复N次，直到返回成功，N是可以输入的

### `ConditionNode`

#### `Fallbacks`

可以理解为后备，如果当前节点失败了，则"tick"下一个节点

如果某个子节点返回`SUCCESS`，则该节点返回`SUCCESS`，且中断后面的所有节点(通过这种方式可以打断异步行为)

有两个变种，主要区别在于子节点返回`RUNNING`时"tick"的节点不同

<img alt="image-20230316181954457.png" src="http://120.133.136.23:8888/uploadImages/110/53/160/6/2023/03/16/18/22/7c41bcd1-7c10-489f-8923-af77a6d73442.png" >

### `ActionNode`

没有子节点，由用户自己自定

