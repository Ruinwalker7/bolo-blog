title: 我在 GitHub 上的开源项目
date: '2023-02-25 16:33:53'
updated: '2023-02-25 16:33:53'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](/images/github_repo.jpg)

## Github Stats

![Github Stats](https://github-readme-stats.vercel.app/api?username=Ruinwalker7&show_icons=true) 

## 所有开源项目
| 仓库 |  项目简介 | Stars | fork | 编程语言 |
| ---- | ---- | ---- | ---- | ---- |
| [bolo-blog](https://github.com/Ruinwalker7/bolo-blog) | ✍️ root 的个人博客 - 记录精彩的程序人生 | 0 | 0 | |
| [Broadcast-Whitepaper-SAA](https://github.com/Ruinwalker7/Broadcast-Whitepaper-SAA) |  | 0 | 0 | |
| [College-evaluation-system](https://github.com/Ruinwalker7/College-evaluation-system) | 信息作业 | 0 | 0 | Python|
| [CSUAutoSelect](https://github.com/Ruinwalker7/CSUAutoSelect) |  | 0 | 0 | Python|
| [FYT-sentry](https://github.com/Ruinwalker7/FYT-sentry) |  | 0 | 0 | C++|
| [GuessGame](https://github.com/Ruinwalker7/GuessGame) | a guess game with javafx | 0 | 0 | Java|
| [Ruinwalker7](https://github.com/Ruinwalker7/Ruinwalker7) |  | 0 | 0 | |
